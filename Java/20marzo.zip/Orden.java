//Orden.java
//Luis Angel Martinez, Jorge Luis Marquez
import java.util.*;

public class Orden {
	private Cliente cliCliente;
	private Envio envEnvio;
	private Factura facFactura;
	private Vector<Producto> Productos;

	public static void main(String args[]){

	}
}

class Envio{
	private Vector<Orden> Ordenes;
}

class Factura {
	private Pago pagPago;
	private Orden ordOrden;
}

class Cliente{
	private Vector<Orden> Ordenes;
}

class Producto{
	private Vector<Orden> Ordenes;
	private Vector<Instructivo> Instructivos;
}

class Pago{
	private Factura facFactura;
}

class Instructivo{
	
}