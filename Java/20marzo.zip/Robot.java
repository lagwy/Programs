//Robot.java
//Luis Angel Martinez, Jorge Luis Marquez

public class Robot{
	public static void main(String args[]){

	}
	private Camara Camara1;
	private Camara Camara2;
	private Brazo BrazoIzq;
	private Brazo BrazoDer;

}

class Camara{
	
}

class Brazo{
	private Mano manMano;
	


}

class Mano{
	private Brazo braBrazo;
	private MotorPasos motMotor;
	private ILocomocion motor;

	void setLocomocion(ILocomocion il){
		motor = il;
	}
}

class MotorPasos implements ILocomocion{
	private Mano manMano;

	public void unMetodo(){

	}
}

class MotorDC implements ILocomocion{
	public void unMetodo(){

	}
}

interface ILocomocion{
	void unMetodo();
}