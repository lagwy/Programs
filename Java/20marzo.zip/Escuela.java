//Escuela.java
//Luis Angel Martinez, Jorge Luis Marquez
import java.util.*;

public class Escuela{
	public static void main(String args[]){

	}
	private Vector<Departamento> Departamentos;
	private Vector<Estudiante> Estudiantes;
}

class Estudiante{
	private Vector<Curso> Cursos;
}

class Departamento{
	private Profesor Jefe;
	private Vector<Profesor> Profesores;
	private Vector<Curso> Cursos;
}

class Curso{
	private Vector<Estudiante> Estudiantes;
	private Vector<Profesor> Profesores;
}

class Profesor{
	private Vector<Curso> Cursos;
}