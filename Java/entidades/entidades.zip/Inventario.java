package entidades;
import java.util.*;

public class Inventario{
	private int fecha;
	private int numeroRev;
	private Vector<Revista> revistas;

	public void agregarRevista(){

	}

	public void quitarRevista(){

	}

	public int totalRevistas(int numeroRev){
		
		return 0;
	}

	public void numeroRev(){

	}

	public void enviarRevistas(int numeroRev){

	}
}