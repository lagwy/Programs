package entidades;
import java.util.*;

public class RegistroDePago{
	private String fecha;
	private String cantidad;

	public void cancelarRegistro(){

	}	
}