package entidades;
import java.util.*;

public class EditorenJefe {
		private int id;
		private String nombre;
		private String direccion;
		private String telefono;
		private Vector <Articulo> articulos;

		public void revisarArticulo () {

		}
		public void seleccionarArticulo () {

		}
		public void escribirCarta () {

		}
		public void asignarSuscripcion() {

		}
		public void anularSuscripcion() {

		}
}