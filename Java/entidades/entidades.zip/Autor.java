package entidades;
import java.util.*;

public class Autor {
	private int id;
	private String nombre;
	private String direccion;
	private String telefono;
	private Vector <Articulo> articulos;

	public void buscarAutor(String nombre) {

	}
	public void contratarAutor() {

	}
	public void entregarArticulo() {

	}
	public void asignarSuscripcionAnual() {

	}
	public void anularSuscripcion() {

	}
}