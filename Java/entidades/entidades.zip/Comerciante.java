package entidades;
import java.util.*;

public class Comerciante{
	private int id;
	private String direccion;
	private int telefono;
	private Vector<Revista> revistas;

	public void recibirRevistas(){

	}

	public void devolverRevistas(){

	}

	public void agregarComerciante(){

	}
}