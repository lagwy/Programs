package entidades;
import java.util.*;

public class Revista {
	private int id;
	private String nombre;
	private String fecha;
	private String formato;
	private int ejemplaresVendidos;
	private Vector<Comerciante> comerciantes;
	private Vector<Articulo> articulos;


	public void agregarArticulo(){

	}

	public void quitarArticulo(){

	}

	public void imprimirRevista(){

	}

}