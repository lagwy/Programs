package entidades;
import java.util.*;

public class Suscriptor {
	private int id;
	private String nombre;
	private String direccion;
	private String telefono;
	private String correo;
	private int caducidad;
	private String tipoSuscriptor;
	private Vector<Revista> revistas;

	public void confirmarSuscripcion(){

	}

	public void renovarSuscripcion(){

	}

	public void anularSuscripcion(){

	}
}