package entidades;
import java.util.*;

public class Juez {
	private int id;
	private String nombre;
	private String direccion;
	private String telefono;
	private int articulosPendientes;
	private int tiempoCargo;
	private Vector <Articulo> articulos;

	public void contratarJuez() {

	}
	public void retirarCargo(int tiempoCargo) {

	}
	public void calificarArticulo() {

	}
	public void asignarSuscripcionGratuita() {

	}
	public void anularSuscripcionGratuita() {
	
	}
}